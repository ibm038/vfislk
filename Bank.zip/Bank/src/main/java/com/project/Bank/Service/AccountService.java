package com.project.Bank.Service;

import com.project.Bank.DAO.AccountData;
import com.project.Bank.Templates.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Iterator;


@Component
public class AccountService
{
    @Autowired
    AccountData data;

    public AccountService() {
    }

    public Account getAccount(int accountNo)
    {
        Iterator<Account> it= data.getData().iterator();
        Account ac;
        while(it.hasNext())
        {
            ac=it.next();
            if(ac.getAccountNo() == accountNo)
                return ac;
        }
        return null;
    }
}
