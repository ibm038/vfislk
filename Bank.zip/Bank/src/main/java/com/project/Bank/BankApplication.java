package com.project.Bank;

import com.project.Bank.Service.AccountService;
import com.project.Bank.Templates.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@ComponentScan
@SpringBootApplication
@RestController
public class BankApplication {

	@Autowired
	AccountService accSer;

	public static void main(String[] args) {
		SpringApplication.run(BankApplication.class, args);
	}

	@GetMapping("/test")
	public String testController()
	{
		return "Working";
	}

	@GetMapping("/account")
	public Account getAccount(@RequestParam("accountNo") int accountNo)
	{
		return  accSer.getAccount(accountNo);
	}

	//Just For Testing Purpose
	@GetMapping("/accountFull")
	public String getAccountFull(@RequestParam("accountNo") int accountNo,@RequestParam("identifier") String indentifier)
	{
		return "Working"+accountNo+""+indentifier;
	}
}
