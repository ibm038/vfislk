package com.project.Bank.DAO;

import com.project.Bank.Templates.Account;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class AccountData
{
    public AccountData() {
    }

    public List< Account> getData()
    {

        List<Account> data= new ArrayList<Account>();
        data.add(new Account(1,"kaushal",10000,100,50));
        data.add(new Account(2,"Akash",12000,1000,500));
        data.add(new Account(3,"Parth",15000,1010,700));
        data.add(new Account(4,"Prashant",20000,2100,500));
        data.add(new Account(5,"Amit",80000,5100,5000));

        return data;
    }
}
