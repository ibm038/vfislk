package com.project.Bank.Templates;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class Account
{
    int accountNo;
    String name;
    double balance;
    double laon;
    double remainingLoan;

    public Account() {
    }

    public Account(int accountNo, String name, double balance, double laon, double remainingLoan) {
        this.accountNo = accountNo;
        this.name = name;
        this.balance = balance;
        this.laon = laon;
        this.remainingLoan = remainingLoan;
    }

    public int getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(int accountNo) {
        this.accountNo = accountNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public double getLaon() {
        return laon;
    }

    public void setLaon(double laon) {
        this.laon = laon;
    }

    public double getRemainingLoan() {
        return remainingLoan;
    }

    public void setRemainingLoan(double remainingLoan) {
        this.remainingLoan = remainingLoan;
    }
}
